import java.io.File;
import java.util.List;

import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.ThresholdUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.UserBasedRecommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;


public class App {
	static final String inputFile = "/user/cloudera/data/ratings.dat";
	static final String outputFile = "/home/cloudera/small.csv";

	public static void main(String[] args) throws Exception {
		// create data source (model) - from the csv file
		File ratingsFile = new File(outputFile);
		DataModel model = new FileDataModel(ratingsFile);
		// create a simple recommender on our data
		UserSimilarity similarity = new PearsonCorrelationSimilarity(model);
		UserNeighborhood neighborhood = new ThresholdUserNeighborhood(0.1,similarity, model);
		UserBasedRecommender recommender = new GenericUserBasedRecommender(
				model, neighborhood, similarity
				);

		// for all users
		for (LongPrimitiveIterator it = model.getUserIDs(); it.hasNext();) {
			long userId = it.nextLong();
			// get the recommendations for the user
			List<RecommendedItem> recommendations = recommender.recommend(
					userId, 10);
			for (RecommendedItem recommendation : recommendations) {
				System.out.println(recommendation);
			}

		}
	}
}