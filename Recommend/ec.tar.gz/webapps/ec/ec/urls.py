from django.conf.urls import patterns, include, url
from webapp.views import home, tracks
# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
     url(r'^$', home, name='home'),
     url(r'^tracks/$', tracks, name='tracks'),
    # url(r'^ec/', include('ec.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),
     (r'^static/(?P<path>.*)$', 'django.views.static.serve', {'document_root': '/webapps/ec/static/'})
    # Uncomment the next line to enable the admin:
    # url(r'^admin/', include(admin.site.urls)),
)
