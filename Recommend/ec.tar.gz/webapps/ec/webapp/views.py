#encoding=utf-8
from django.shortcuts import render
from django.contrib.auth import logout as auth_logout
from django.shortcuts import render_to_response, HttpResponse, redirect
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
import json
from urllib import unquote
def home(request):
    context = {'latest_question_list': 'latest_question_list'}
    return render(request, 'profile.html', context)

@csrf_exempt
def tracks(request):
    if request.method== 'POST':
        f = open('/tmp/postlog.txt', 'wa')
        posted_data = request.body
        f.write(unquote(posted_data))
        f.write('\n')
        f.close()
        return HttpResponse(unquote(posted_data), mimetype='application/json; charset=UTF-8')
